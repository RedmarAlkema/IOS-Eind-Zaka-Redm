import SwiftUI

@main
struct IOS_Eind_Zaka_RedmApp: App {
    var body: some Scene {	
        WindowGroup {
            MainTabView()
        }
    }
}
